#!/usr/bin/env bash
# Certificates for the TAKVox token service (mutual TLS).
#
#   ./gen-certs.sh server <ca.pem> <ca.key> <host-or-ip> [outdir]
#       Issues the token service certificate signed by YOUR TAK server's CA, so ATAK
#       already trusts it. Also copies the CA as client-ca.pem (used to verify clients).
#       OpenTAKServer: the CA is in its ca/ folder (ca.pem and ca-do-not-share.key).
#       TAK Server:    /opt/tak/certs/files/ca.pem and ca-do-not-share.key (or your CA key).
#
#   ./gen-certs.sh devca <host-or-ip> [outdir]
#       TESTING ONLY: creates a throwaway CA, a server certificate and a test client certificate.
set -euo pipefail

cmd="${1:-}"; shift || true
san_for() { if [[ "$1" =~ ^[0-9.]+$ ]]; then echo "IP:$1"; else echo "DNS:$1"; fi; }

issue_server() {  # ca.pem ca.key host out
  local ca="$1" cakey="$2" host="$3" out="$4"
  mkdir -p "$out"
  openssl genrsa -out "$out/token.key" 2048 2>/dev/null
  openssl req -new -key "$out/token.key" -subj "/CN=$host" -out "$out/token.csr"
  printf "subjectAltName=%s\nextendedKeyUsage=serverAuth\nkeyUsage=digitalSignature,keyEncipherment\n" \
    "$(san_for "$host")" > "$out/ext.cnf"
  openssl x509 -req -in "$out/token.csr" -CA "$ca" -CAkey "$cakey" -CAcreateserial \
    -days 825 -sha256 -extfile "$out/ext.cnf" -out "$out/token.pem"
  cp "$ca" "$out/client-ca.pem"
  rm -f "$out/token.csr" "$out/ext.cnf"
  echo "OK: $out/token.pem  $out/token.key  $out/client-ca.pem"
}

case "$cmd" in
  server)
    [[ $# -ge 3 ]] || { sed -n '2,13p' "$0"; exit 1; }
    issue_server "$1" "$2" "$3" "${4:-./certs}"
    ;;
  devca)
    [[ $# -ge 1 ]] || { sed -n '2,13p' "$0"; exit 1; }
    host="$1"; out="${2:-./certs-dev}"; mkdir -p "$out"
    openssl genrsa -out "$out/ca.key" 2048 2>/dev/null
    openssl req -x509 -new -key "$out/ca.key" -sha256 -days 365 -subj "/CN=TAKVox Dev CA" -out "$out/ca.pem"
    issue_server "$out/ca.pem" "$out/ca.key" "$host" "$out"
    openssl genrsa -out "$out/client.key" 2048 2>/dev/null
    openssl req -new -key "$out/client.key" -subj "/CN=test-user" -out "$out/client.csr"
    printf "extendedKeyUsage=clientAuth\n" > "$out/c.cnf"
    openssl x509 -req -in "$out/client.csr" -CA "$out/ca.pem" -CAkey "$out/ca.key" -CAcreateserial \
      -days 365 -sha256 -extfile "$out/c.cnf" -out "$out/client.pem" 2>/dev/null
    rm -f "$out/client.csr" "$out/c.cnf"
    echo "OK (test): CA, server and client 'test-user' in $out"
    ;;
  *) sed -n '2,13p' "$0"; exit 1 ;;
esac
