#!/usr/bin/env python3
"""
TAKVox token service
====================
Emite tokens de acesso do LiveKit para o plugin TAKVox.

Funciona com QUALQUER servidor TAK (TAK Server, OpenTAKServer, GoTAK, FreeTAKServer...)
porque NÃO fala com o servidor TAK: ele só confere se quem pede o token possui um
certificado cliente assinado pela mesma CA que o servidor TAK usa (mTLS). O ATAK já tem
esse certificado instalado, então não há login extra.

Modos de autenticação (AUTH_MODE):
  mtls    - exige certificado cliente assinado por TLS_CLIENT_CA  (recomendado)
  key     - exige o cabeçalho X-TVX-Key igual a TEAM_KEY          (sem certificados)
  either  - aceita qualquer um dos dois

Canais:
  - "Estáticos": definidos em CHANNELS_FILE (admin), com allow_cn opcional.
  - "Criados pela equipe": qualquer pessoa autenticada pode criar um canal novo com
    POST /v1/channels, com nome, descrição e uma SENHA própria daquele canal. O canal
    passa a aparecer para todo mundo que atualizar GET /v1/channels (com "protected":
    true, nunca a senha em si), e para entrar nele é preciso mandar essa senha em
    POST /v1/token. São persistidos em DYNAMIC_CHANNELS_FILE (precisa ser um caminho
    GRAVÁVEL — não confundir com CHANNELS_FILE, que pode continuar somente leitura).

Somente biblioteca padrão do Python 3.8+ (sem pip).
"""
import base64
import binascii
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import ssl
import sys
import threading
import time
import unicodedata
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

log = logging.getLogger("takvox-token")

# --------------------------------------------------------------------------- config
def env(name, default=None, required=False):
    v = os.environ.get(name, default)
    if required and not v:
        sys.exit(f"[erro] variável de ambiente obrigatória ausente: {name}")
    return v

LIVEKIT_URL = env("LIVEKIT_URL", required=True)          # URL que o ATAK usa (ws:// ou wss://)
API_KEY = env("LIVEKIT_API_KEY", required=True)
API_SECRET = env("LIVEKIT_API_SECRET", required=True)
AUTH_MODE = env("AUTH_MODE", "mtls").lower()
TEAM_KEY = env("TEAM_KEY", "")
TLS_CERT = env("TLS_CERT", "")
TLS_KEY = env("TLS_KEY", "")
TLS_CLIENT_CA = env("TLS_CLIENT_CA", "")
BIND = env("BIND", "0.0.0.0")
PORT = int(env("PORT", "8443"))
TOKEN_TTL = int(env("TOKEN_TTL", "3600"))
CHANNELS_FILE = env("CHANNELS_FILE", "/config/channels.json")
DYNAMIC_CHANNELS_FILE = env("DYNAMIC_CHANNELS_FILE", "/data/dynamic_channels.json")
ROOM_PREFIX = env("ROOM_PREFIX", "tvx-")

SAFE_ID = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")
SAFE_UID = re.compile(r"^[A-Za-z0-9_.:@\-]{1,128}$")

MAX_DYNAMIC_CHANNELS = int(env("MAX_DYNAMIC_CHANNELS", "200"))
MIN_CHANNEL_PASSWORD_LEN = 4
PBKDF2_ITERATIONS = 200_000


# --------------------------------------------------------------------------- canais estáticos
def load_channels():
    with open(CHANNELS_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    out = []
    for c in data.get("channels", []):
        if not SAFE_ID.match(c.get("id", "")):
            sys.exit(f"[erro] id de canal inválido em {CHANNELS_FILE}: {c.get('id')!r}")
        c.setdefault("name", c["id"])
        c.setdefault("description", "")
        c.setdefault("allow_cn", ["*"])
        c.setdefault("video", True)
        out.append(c)
    if not out:
        sys.exit("[erro] nenhum canal configurado")
    return out


CHANNELS = load_channels()
STATIC_IDS = {c["id"] for c in CHANNELS}


# --------------------------------------------------------------------------- canais dinâmicos
# Protegidos por um lock de processo: o http.server é multi-thread (ThreadingHTTPServer),
# então leitura+escrita do arquivo precisa ser serializada para não corromper o JSON.
_dyn_lock = threading.Lock()


def _dyn_load_unlocked():
    if not os.path.exists(DYNAMIC_CHANNELS_FILE):
        return []
    try:
        with open(DYNAMIC_CHANNELS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("channels", [])
    except Exception as e:
        log.error("falha ao ler %s: %s (tratando como vazio)", DYNAMIC_CHANNELS_FILE, e)
        return []


def _dyn_save_unlocked(channels):
    os.makedirs(os.path.dirname(DYNAMIC_CHANNELS_FILE) or ".", exist_ok=True)
    tmp = DYNAMIC_CHANNELS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"channels": channels}, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DYNAMIC_CHANNELS_FILE)  # troca atômica, sem arquivo corrompido a meio caminho


def slugify(name, existing_ids):
    norm = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", norm.lower()).strip("-") or "canal"
    slug = slug[:40]
    candidate = slug
    n = 2
    while candidate in existing_ids:
        candidate = f"{slug}-{n}"
        n += 1
    return candidate


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2${PBKDF2_ITERATIONS}${binascii.hexlify(salt).decode()}${binascii.hexlify(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, iters, salt_hex, hash_hex = stored.split("$")
        if scheme != "pbkdf2":
            return False
        salt = binascii.unhexlify(salt_hex)
        expected = binascii.unhexlify(hash_hex)
    except Exception:
        return False
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iters))
    return hmac.compare_digest(dk, expected)


def create_dynamic_channel(name, description, video, password, created_by):
    with _dyn_lock:
        current = _dyn_load_unlocked()
        if len(current) >= MAX_DYNAMIC_CHANNELS:
            raise ValueError(f"limite de {MAX_DYNAMIC_CHANNELS} canais criados pela equipe atingido")
        existing_ids = STATIC_IDS | {c["id"] for c in current}
        chan_id = slugify(name, existing_ids)
        entry = {
            "id": chan_id,
            "name": name,
            "description": description,
            "video": video,
            # Senha é opcional: canal sem senha pode ser apagado por qualquer pessoa
            # autenticada; canal com senha exige a senha pra apagar (igual a entrar nele).
            "password_hash": hash_password(password) if password else None,
            "created_by": created_by,
            "created_at": int(time.time()),
        }
        current.append(entry)
        _dyn_save_unlocked(current)
        return entry


def find_dynamic_channel(chan_id):
    with _dyn_lock:
        for c in _dyn_load_unlocked():
            if c["id"] == chan_id:
                return c
    return None


def all_dynamic_channels():
    with _dyn_lock:
        return _dyn_load_unlocked()


def delete_dynamic_channel(chan_id):
    """Remove um canal criado pela equipe. Retorna o registro removido, ou None se
    não existir. Chamador já deve ter verificado senha (se houver) antes de chamar."""
    with _dyn_lock:
        current = _dyn_load_unlocked()
        removed = None
        kept = []
        for c in current:
            if c["id"] == chan_id and removed is None:
                removed = c
            else:
                kept.append(c)
        if removed is not None:
            _dyn_save_unlocked(kept)
        return removed


# --------------------------------------------------------------------------- JWT (HS256)
def b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def make_token(identity, name, metadata, room, can_video):
    now = int(time.time())
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "iss": API_KEY,
        "sub": identity,
        "nbf": now,
        "exp": now + TOKEN_TTL,
        "name": name,
        "metadata": metadata,
        "video": {
            "roomJoin": True,
            "room": room,
            "canPublish": True,
            "canSubscribe": True,
            "canPublishData": True,
            # se o canal não permite vídeo, restringe as fontes publicáveis
            **({} if can_video else {"canPublishSources": ["microphone"]}),
        },
    }
    signing = ".".join(
        b64url(json.dumps(p, separators=(",", ":")).encode()) for p in (header, payload)
    )
    sig = hmac.new(API_SECRET.encode(), signing.encode(), hashlib.sha256).digest()
    return f"{signing}.{b64url(sig)}"


# --------------------------------------------------------------------------- auth
def peer_cn(conn):
    """CN do certificado cliente (ou None). Só existe se o TLS exigiu o certificado."""
    try:
        cert = conn.getpeercert()
    except Exception:
        return None
    if not cert:
        return None
    for rdn in cert.get("subject", ()):
        for k, v in rdn:
            if k == "commonName":
                return v
    return None


def authenticate(handler):
    """Retorna (ok, principal, motivo)."""
    if AUTH_MODE in ("mtls", "either"):
        cn = peer_cn(handler.connection) if isinstance(handler.connection, ssl.SSLSocket) else None
        if cn:
            return True, cn, ""
    if AUTH_MODE in ("key", "either"):
        given = handler.headers.get("X-TVX-Key", "")
        if TEAM_KEY and hmac.compare_digest(given.encode(), TEAM_KEY.encode()):
            return True, "key:" + hashlib.sha256(given.encode()).hexdigest()[:8], ""
        return False, None, "chave inválida"
    return False, None, "certificado cliente ausente ou inválido"


def visible_static_channels(principal):
    out = []
    for c in CHANNELS:
        allow = c["allow_cn"]
        # principais "key:*" (chave de equipe) só enxergam canais abertos ("*"),
        # nunca canais restritos por lista de CN.
        if "*" in allow or principal in allow:
            out.append(c)
    return out


# --------------------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = "TAKVoxToken/1.1"

    def log_message(self, fmt, *args):
        log.info("%s - %s", self.address_string(), fmt % args)

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self, max_len=4096):
        n = int(self.headers.get("Content-Length", "0"))
        if n <= 0 or n > max_len:
            raise ValueError("tamanho inválido")
        return json.loads(self.rfile.read(n))

    def do_GET(self):
        try:
            self._handle_GET()
        except Exception as e:
            self._fail_safely(e)

    def _handle_GET(self):
        if self.path == "/healthz":
            return self._send(200, {"ok": True})
        ok, who, why = authenticate(self)
        if not ok:
            return self._send(401, {"error": why})
        if self.path == "/v1/channels":
            chans = [
                {"id": c["id"], "name": c["name"], "description": c["description"],
                 "video": c["video"], "protected": False, "deletable": False}
                for c in visible_static_channels(who)
            ]
            for c in all_dynamic_channels():
                chans.append({
                    "id": c["id"], "name": c["name"], "description": c["description"],
                    "video": c["video"], "protected": c.get("password_hash") is not None,
                    "deletable": True,
                })
            return self._send(200, {"channels": chans, "principal": who})
        self._send(404, {"error": "não encontrado"})

    def do_POST(self):
        try:
            self._handle_POST()
        except Exception as e:
            self._fail_safely(e)

    def _handle_POST(self):
        ok, who, why = authenticate(self)
        if not ok:
            return self._send(401, {"error": why})

        if self.path == "/v1/channels":
            return self._create_channel(who)
        if self.path == "/v1/token":
            return self._issue_token(who)
        self._send(404, {"error": "não encontrado"})

    def do_DELETE(self):
        try:
            self._handle_DELETE()
        except Exception as e:
            self._fail_safely(e)

    def _handle_DELETE(self):
        ok, who, why = authenticate(self)
        if not ok:
            return self._send(401, {"error": why})

        prefix = "/v1/channels/"
        if self.path.startswith(prefix):
            chan_id = self.path[len(prefix):]
            return self._delete_channel(who, chan_id)
        self._send(404, {"error": "não encontrado"})

    def _delete_channel(self, who, chan_id):
        if not SAFE_ID.match(chan_id):
            return self._send(400, {"error": "id de canal inválido"})
        if chan_id in STATIC_IDS:
            return self._send(403, {"error": "canal fixo do servidor — não pode ser apagado por aqui"})

        dyn = find_dynamic_channel(chan_id)
        if dyn is None:
            return self._send(404, {"error": "canal inexistente"})

        if dyn.get("password_hash") is not None:
            try:
                req = self._read_json_body()
            except Exception:
                req = {}
            password = str(req.get("password", ""))
            if not verify_password(password, dyn["password_hash"]):
                return self._send(403, {"error": "senha do canal incorreta"})

        removed = delete_dynamic_channel(chan_id)
        if removed is None:
            # Já foi apagado por outra requisição concorrente entre a checagem e aqui.
            return self._send(404, {"error": "canal inexistente"})

        log.info("canal apagado: id=%s por=%s", chan_id, who)
        self._send(200, {"ok": True, "id": chan_id})

    def _fail_safely(self, e: Exception):
        """Rede de segurança: qualquer erro não previsto termina numa resposta 500 clara,
        nunca numa conexão travada sem resposta (o tipo de falha mais difícil de diagnosticar
        de fora). O detalhe completo vai pro log do servidor; o cliente recebe só o essencial."""
        log.exception("erro não tratado processando %s %s", self.command, self.path)
        try:
            self._send(500, {"error": f"erro interno no servidor: {e}"})
        except Exception:
            pass  # conexão já pode estar quebrada; não há mais nada a fazer aqui

    def _create_channel(self, who):
        try:
            req = self._read_json_body()
        except Exception:
            return self._send(400, {"error": "JSON inválido"})

        name = str(req.get("name", "")).strip()[:64]
        description = str(req.get("description", "")).strip()[:200]
        video = bool(req.get("video", True))
        password = str(req.get("password", ""))

        if not name:
            return self._send(400, {"error": "informe um nome para o canal"})
        # Senha agora é opcional: canal sem senha fica aberto (qualquer autenticado
        # pode entrar e apagar); se informada, precisa ter o tamanho mínimo.
        if password and len(password) < MIN_CHANNEL_PASSWORD_LEN:
            return self._send(400, {"error": f"a senha precisa ter pelo menos {MIN_CHANNEL_PASSWORD_LEN} caracteres, ou deixe em branco para um canal sem senha"})

        try:
            entry = create_dynamic_channel(name, description, video, password, who)
        except ValueError as e:
            return self._send(409, {"error": str(e)})
        except OSError as e:
            # ex.: PermissionError gravando em DYNAMIC_CHANNELS_FILE — erro de implantação
            # (permissão/volume), não do usuário. Nunca deve travar a conexão em silêncio.
            log.error("falha ao salvar canal dinâmico: %s", e)
            return self._send(500, {"error": f"falha ao salvar o canal no servidor: {e}"})

        log.info("canal criado: id=%s nome=%r por=%s protegido=%s", entry["id"], name, who, entry["password_hash"] is not None)
        self._send(200, {
            "id": entry["id"], "name": entry["name"], "description": entry["description"],
            "video": entry["video"], "protected": entry["password_hash"] is not None,
            "deletable": True,
        })

    def _issue_token(self, who):
        try:
            req = self._read_json_body()
        except Exception:
            return self._send(400, {"error": "JSON inválido"})

        chan_id = str(req.get("channel", ""))
        uid = str(req.get("uid", ""))
        callsign = str(req.get("callsign", ""))[:64] or uid
        password = str(req.get("password", ""))
        if not SAFE_UID.match(uid):
            return self._send(400, {"error": "uid inválido"})

        chan = next((c for c in visible_static_channels(who) if c["id"] == chan_id), None)
        if chan is not None:
            can_video = chan["video"]
        else:
            dyn = find_dynamic_channel(chan_id)
            if dyn is None:
                return self._send(403, {"error": "canal inexistente ou sem permissão"})
            if dyn.get("password_hash") is not None and not verify_password(password, dyn["password_hash"]):
                return self._send(403, {"error": "senha do canal incorreta"})
            chan = dyn
            can_video = dyn["video"]

        meta = json.dumps({"uid": uid, "callsign": callsign, "principal": who}, separators=(",", ":"))
        token = make_token(uid, callsign, meta, ROOM_PREFIX + chan["id"], can_video)
        log.info("token emitido: principal=%s uid=%s canal=%s", who, uid, chan["id"])
        self._send(200, {
            "server_url": LIVEKIT_URL,
            "participant_token": token,
            "identity": uid,
            "channel": chan["id"],
            "room": ROOM_PREFIX + chan["id"],
            "video": can_video,
        })


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if AUTH_MODE not in ("mtls", "key", "either"):
        sys.exit("[erro] AUTH_MODE deve ser mtls, key ou either")
    if AUTH_MODE in ("key", "either") and len(TEAM_KEY) < 16:
        sys.exit("[erro] TEAM_KEY precisa ter pelo menos 16 caracteres")
    if AUTH_MODE in ("mtls", "either") and not (TLS_CERT and TLS_KEY and TLS_CLIENT_CA):
        sys.exit("[erro] modo mtls exige TLS_CERT, TLS_KEY e TLS_CLIENT_CA")

    httpd = ThreadingHTTPServer((BIND, PORT), Handler)
    if TLS_CERT:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(TLS_CERT, TLS_KEY)
        if TLS_CLIENT_CA:
            ctx.load_verify_locations(TLS_CLIENT_CA)
            # 'either' precisa aceitar conexões sem certificado (cai no modo chave)
            ctx.verify_mode = ssl.CERT_REQUIRED if AUTH_MODE == "mtls" else ssl.CERT_OPTIONAL
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        scheme = "https"
    else:
        scheme = "http"
        log.warning("TLS desativado: use apenas em rede confiável ou atrás de um proxy TLS")
    log.info("TAKVox token service em %s://%s:%d  (auth=%s, %d canais estáticos, canais dinâmicos em %s)",
             scheme, BIND, PORT, AUTH_MODE, len(CHANNELS), DYNAMIC_CHANNELS_FILE)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
