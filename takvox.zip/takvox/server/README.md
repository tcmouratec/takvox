# TAKVox server

Everything you need to host the backend for the TAKVox ATAK plugin: a **LiveKit** media server and the **token service** that decides who may join.

*Português: [README.pt-BR.md](README.pt-BR.md)*

```
 ATAK + TAKVox --HTTPS + TAK client certificate--> takvox-token --(JWT)--+
        |                                                                |
        +------------- WebRTC (audio/video) ----------------> LiveKit <--+
```

**Why two services?** LiveKit only lets someone into a room with a JWT signed by its API key. The ATAK client certificate means nothing to LiveKit. The token service checks the certificate (mutual TLS) and hands out that JWT. It does not talk to your TAK server, so any server whose CA signed the ATAK client certificates works (tested with OpenTAKServer).

## Requirements
- A Linux host with Docker and Docker Compose (a Raspberry Pi 5 is enough for a small team).
- Your TAK server's CA certificate **and** CA key (to sign the token service certificate).
- Phones must reach the server: same LAN, VPN (WireGuard, for example) or a public IP.

## Files
| File | What it is |
|---|---|
| `docker-compose.yml` | LiveKit + Redis + token service |
| `.env.example` | API key/secret, public URL, auth mode (copy to `.env`) |
| `livekit.yaml.example` | LiveKit config (copy to `livekit.yaml`) |
| `takvox-token/token_service.py` | The token service (Python standard library only) |
| `takvox-token/channels.json` | Fixed channels (edit freely) |
| `scripts/gen-certs.sh` | Issues the service certificate from your TAK CA |

## Set up from scratch

**1. Get the files** onto the server and enter the folder (`cd server`).

**2. Configuration**
```bash
cp .env.example .env
cp livekit.yaml.example livekit.yaml
```
Edit `.env`: set `LIVEKIT_API_KEY` and `LIVEKIT_API_SECRET` (`openssl rand -hex 8` and `openssl rand -hex 32`) and `LIVEKIT_PUBLIC_URL` (for example `ws://192.168.1.10:7880`). Edit `livekit.yaml`: set `node_ip` to the server's IP on the network the phones use.

**3. Certificate for the token service** (signed by your TAK server's CA, so ATAK already trusts it). The host must be the IP or name the phones will use in the token URL; it goes in the certificate's SAN.
```bash
./scripts/gen-certs.sh server /path/to/ca.pem /path/to/ca-key.pem 192.168.1.10 ./takvox-token/certs
```
- OpenTAKServer: the CA is in its `ca/` folder. The key may be passphrase-protected, and you may need `sudo` to read it.
- Let the container user read the files (it runs as UID 65534) and let it write the data folder:
```bash
sudo chown 65534:65534 takvox-token/certs/* takvox-token/data
chmod 600 takvox-token/certs/token.key
```
> No TAK CA to test with? `./scripts/gen-certs.sh devca 192.168.1.10 ./certs-dev` creates a throwaway CA, server certificate and a test client certificate. Not for real use.

**4. Open the ports** on the server firewall: `7880/tcp`, `7881/tcp`, `50000-50100/udp`, `8091/tcp`.

**5. Start**
```bash
docker compose up -d --build
docker compose logs -f takvox-token
```
The log should say `TAKVox token service em https://0.0.0.0:8091 (auth=mtls, ...)`.

**6. On the phone:** import your TAK server's data package in ATAK as usual (this installs the client certificate), install the TAKVox APK, open **TAKVox > Settings**, set the token server URL to `https://<server-ip>:8091` and tap **Test**. Leave **Team key** empty in `mtls` mode.

## Adjusting

| I want to... | Do this |
|---|---|
| Change fixed channels | Edit `takvox-token/channels.json`, then `docker compose restart takvox-token`. |
| Restrict a channel to some users | Add `"allow_cn": ["cn1", "cn2"]` (the certificate CNs). Default is open to everyone. |
| Make a channel voice-only | Add `"video": false`. |
| Change the token service code | `docker compose up -d --build takvox-token`. **`restart` does not reload the code**: the file is copied into the image at build time. |
| Allow a shared key as well | In `.env`: `TAKVOX_AUTH_MODE=either` and `TAKVOX_TEAM_KEY` with 16+ characters. Use only on trusted networks. |
| Use only a shared key (no certificates) | `TAKVOX_AUTH_MODE=key`. The service still starts with TLS if the certificate files exist. |
| Serve phones over the internet | `use_external_ip: true` in `livekit.yaml` (remove `node_ip`), forward the ports above, and put a TLS reverse proxy in front of port 7880 so the URL is `wss://`. |
| Wipe channels created from the app | Stop the service, delete `takvox-token/data/dynamic_channels.json`, start again. |
| Change token lifetime | `TOKEN_TTL` (seconds, default 3600) in the service environment. |

### Channel rules
- **Fixed channels** (`channels.json`) cannot be created or deleted from the app.
- **Team-created channels** are saved in `takvox-token/data/dynamic_channels.json`. The password is optional and stored hashed (PBKDF2). Without a password, anyone authenticated can join and delete it. With a password, joining and deleting both require it.

### Environment variables of the token service
| Variable | Default | Meaning |
|---|---|---|
| `LIVEKIT_URL` | required | URL the phones use for LiveKit (`ws://` or `wss://`) |
| `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET` | required | Must match LiveKit's |
| `AUTH_MODE` | `mtls` | `mtls`, `key` or `either` |
| `TEAM_KEY` | empty | 16+ characters; for `key`/`either` |
| `TLS_CERT`, `TLS_KEY`, `TLS_CLIENT_CA` | empty | Service certificate, its key, and the CA that signs client certificates |
| `PORT` / `BIND` | `8443` / `0.0.0.0` | The compose file sets `PORT=8091` |
| `CHANNELS_FILE` | `/config/channels.json` | Fixed channels |
| `DYNAMIC_CHANNELS_FILE` | `/data/dynamic_channels.json` | Must be writable |
| `ROOM_PREFIX` | `tvx-` | Prefix of LiveKit room names |
| `MAX_DYNAMIC_CHANNELS` | `200` | Limit of team-created channels |

## Quick checks (from a machine that has a client certificate)
```bash
curl --cacert ca.pem --cert client.pem --key client.key https://<server-ip>:8091/v1/channels
```
With `AUTH_MODE=mtls` the TLS handshake itself rejects requests without a valid client certificate, including `/healthz`.

## Troubleshooting
- **`UNKNOWN_CA` / certificate errors in the app:** the phone's client certificate was issued by a different CA than the one in `client-ca.pem`. A phone with a certificate from another TAK server (for example a backup provider) will be rejected.
- **App cannot verify the server:** the host in the token URL must match the certificate's SAN (IP or name used in `gen-certs.sh`).
- **`PermissionError` creating channels:** `takvox-token/data` is not writable by UID 65534 (see step 3).
- **Code change had no effect:** use `up -d --build`, not `restart`.
- **Audio/video does not connect from outside the LAN:** check `node_ip`/`use_external_ip` and the UDP range `50000-50100`.

## Security notes
- Anyone with a valid client certificate can claim another user's `uid` and drop them from a room. Use with a trusted team.
- Never publish `.env`, the certificates or the data folder (they are in `.gitignore`).
- Keep the CA key off the phones and off any shared folder. It is only needed once, to issue the service certificate.

## License
MIT. See [LICENSE](LICENSE). LiveKit is Apache-2.0.
