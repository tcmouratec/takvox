# Servidor do TAKVox

Tudo o que você precisa para hospedar o backend do plugin TAKVox: um servidor de mídia **LiveKit** e o **serviço de tokens**, que decide quem pode entrar.

*English: [README.md](README.md)*

```
 ATAK + TAKVox --HTTPS + certificado cliente do TAK--> takvox-token --(JWT)--+
        |                                                                    |
        +-------------- WebRTC (áudio/vídeo) ------------------> LiveKit <---+
```

**Por que dois serviços?** O LiveKit só deixa alguém entrar em uma sala com um JWT assinado pela chave de API dele. O certificado cliente do ATAK não significa nada para o LiveKit. O serviço de tokens confere o certificado (TLS mútuo) e entrega esse JWT. Ele não conversa com o seu servidor TAK, então funciona com qualquer servidor cuja CA tenha assinado os certificados cliente do ATAK (testado com o OpenTAKServer).

## Requisitos
- Um host Linux com Docker e Docker Compose (um Raspberry Pi 5 basta para uma equipe pequena).
- O certificado da CA do seu servidor TAK **e** a chave da CA (para assinar o certificado do serviço de tokens).
- Os celulares precisam alcançar o servidor: mesma rede local, VPN (WireGuard, por exemplo) ou IP público.

## Arquivos
| Arquivo | O que é |
|---|---|
| `docker-compose.yml` | LiveKit + Redis + serviço de tokens |
| `.env.example` | Chave/segredo da API, URL pública, modo de autenticação (copie para `.env`) |
| `livekit.yaml.example` | Configuração do LiveKit (copie para `livekit.yaml`) |
| `takvox-token/token_service.py` | O serviço de tokens (somente biblioteca padrão do Python) |
| `takvox-token/channels.json` | Canais fixos (edite à vontade) |
| `scripts/gen-certs.sh` | Emite o certificado do serviço a partir da CA do seu TAK |

## Montar do zero

**1. Copie os arquivos** para o servidor e entre na pasta (`cd server`).

**2. Configuração**
```bash
cp .env.example .env
cp livekit.yaml.example livekit.yaml
```
Edite o `.env`: defina `LIVEKIT_API_KEY` e `LIVEKIT_API_SECRET` (`openssl rand -hex 8` e `openssl rand -hex 32`) e `LIVEKIT_PUBLIC_URL` (por exemplo `ws://192.168.1.10:7880`). Edite o `livekit.yaml`: ponha em `node_ip` o IP do servidor na rede que os celulares usam.

**3. Certificado do serviço de tokens** (assinado pela CA do seu servidor TAK, então o ATAK já confia nele). O host deve ser o IP ou nome que os celulares vão usar na URL do token; ele vai no SAN do certificado.
```bash
./scripts/gen-certs.sh server /caminho/ca.pem /caminho/ca-key.pem 192.168.1.10 ./takvox-token/certs
```
- OpenTAKServer: a CA fica na pasta `ca/` dele. A chave pode ter senha, e pode ser preciso `sudo` para lê-la.
- Deixe o usuário do contêiner (UID 65534) ler os arquivos e gravar na pasta de dados:
```bash
sudo chown 65534:65534 takvox-token/certs/* takvox-token/data
chmod 600 takvox-token/certs/token.key
```
> Sem CA do TAK para testar? `./scripts/gen-certs.sh devca 192.168.1.10 ./certs-dev` cria uma CA descartável, o certificado do servidor e um certificado cliente de teste. Não use em produção.

**4. Abra as portas** no firewall do servidor: `7880/tcp`, `7881/tcp`, `50000-50100/udp`, `8091/tcp`.

**5. Suba**
```bash
docker compose up -d --build
docker compose logs -f takvox-token
```
O log deve mostrar `TAKVox token service em https://0.0.0.0:8091 (auth=mtls, ...)`.

**6. No celular:** importe o data package do seu servidor TAK no ATAK como de costume (isso instala o certificado cliente), instale o APK do TAKVox, abra **TAKVox > Configurações**, ponha a URL do servidor de tokens como `https://<ip-do-servidor>:8091` e toque em **Testar**. Deixe **Chave de equipe** vazia no modo `mtls`.

## Ajustes

| Quero... | Faça isto |
|---|---|
| Mudar os canais fixos | Edite `takvox-token/channels.json` e rode `docker compose restart takvox-token`. |
| Restringir um canal a alguns usuários | Acrescente `"allow_cn": ["cn1", "cn2"]` (os CN dos certificados). Por padrão o canal é aberto. |
| Canal só de voz | Acrescente `"video": false`. |
| Mudar o código do serviço | `docker compose up -d --build takvox-token`. **`restart` não recarrega o código**: o arquivo é copiado para a imagem na hora do build. |
| Aceitar também uma chave compartilhada | No `.env`: `TAKVOX_AUTH_MODE=either` e `TAKVOX_TEAM_KEY` com 16+ caracteres. Só em rede confiável. |
| Usar só chave compartilhada (sem certificados) | `TAKVOX_AUTH_MODE=key`. O serviço ainda sobe com TLS se os arquivos de certificado existirem. |
| Atender celulares pela internet | `use_external_ip: true` no `livekit.yaml` (remova `node_ip`), redirecione as portas acima e ponha um proxy reverso com TLS na frente da porta 7880 para a URL ser `wss://`. |
| Apagar os canais criados pelo app | Pare o serviço, apague `takvox-token/data/dynamic_channels.json` e suba de novo. |
| Mudar a validade do token | `TOKEN_TTL` (segundos, padrão 3600) no ambiente do serviço. |

### Regras dos canais
- **Canais fixos** (`channels.json`) não podem ser criados nem apagados pelo app.
- **Canais criados pela equipe** ficam em `takvox-token/data/dynamic_channels.json`. A senha é opcional e fica guardada com hash (PBKDF2). Sem senha, qualquer usuário autenticado entra e pode apagar. Com senha, entrar e apagar exigem a senha.

### Variáveis de ambiente do serviço de tokens
| Variável | Padrão | Significado |
|---|---|---|
| `LIVEKIT_URL` | obrigatória | URL que os celulares usam para o LiveKit (`ws://` ou `wss://`) |
| `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET` | obrigatórias | Devem ser iguais às do LiveKit |
| `AUTH_MODE` | `mtls` | `mtls`, `key` ou `either` |
| `TEAM_KEY` | vazia | 16+ caracteres; para `key`/`either` |
| `TLS_CERT`, `TLS_KEY`, `TLS_CLIENT_CA` | vazias | Certificado do serviço, sua chave, e a CA que assina os certificados cliente |
| `PORT` / `BIND` | `8443` / `0.0.0.0` | O compose define `PORT=8091` |
| `CHANNELS_FILE` | `/config/channels.json` | Canais fixos |
| `DYNAMIC_CHANNELS_FILE` | `/data/dynamic_channels.json` | Precisa ser gravável |
| `ROOM_PREFIX` | `tvx-` | Prefixo dos nomes das salas do LiveKit |
| `MAX_DYNAMIC_CHANNELS` | `200` | Limite de canais criados pela equipe |

## Testes rápidos (de uma máquina que tenha certificado cliente)
```bash
curl --cacert ca.pem --cert client.pem --key client.key https://<ip-do-servidor>:8091/v1/channels
```
Com `AUTH_MODE=mtls`, o próprio handshake TLS recusa quem não apresenta certificado cliente válido, inclusive em `/healthz`.

## Problemas comuns
- **`UNKNOWN_CA` ou erro de certificado no app:** o certificado cliente do celular foi emitido por outra CA, diferente da que está em `client-ca.pem`. Um celular com certificado de outro servidor TAK (por exemplo um provedor de emergência) será recusado.
- **O app não valida o servidor:** o host da URL do token precisa bater com o SAN do certificado (o IP ou nome usado no `gen-certs.sh`).
- **`PermissionError` ao criar canais:** a pasta `takvox-token/data` não é gravável pelo UID 65534 (veja o passo 3).
- **Mudei o código e nada mudou:** use `up -d --build`, não `restart`.
- **Áudio/vídeo não conecta fora da rede local:** confira `node_ip`/`use_external_ip` e a faixa UDP `50000-50100`.

## Segurança
- Quem tem certificado cliente válido pode declarar o `uid` de outro usuário e derrubá-lo da sala. Use com equipe de confiança.
- Nunca publique o `.env`, os certificados nem a pasta de dados (estão no `.gitignore`).
- Mantenha a chave da CA fora dos celulares e de pastas compartilhadas. Ela só é necessária uma vez, para emitir o certificado do serviço.

## Licença
MIT. Veja [LICENSE](LICENSE). O LiveKit é Apache-2.0.
